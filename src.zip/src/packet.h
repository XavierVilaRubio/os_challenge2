#ifndef _PACKET_H_
#define _PACKET_H_

struct info{
  int pfdR;
  int pfdW;
  char* color;
};

#endif